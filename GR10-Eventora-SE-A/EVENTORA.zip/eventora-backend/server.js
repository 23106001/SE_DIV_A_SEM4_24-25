const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');





const app = express();

app.use(express.static(path.join(__dirname, 'public')));



app.use(cors());
app.use(bodyParser.json());

const db = new sqlite3.Database('./events.db', (err) => {
  if (err) console.error(err.message);
  else console.log('Connected to the SQLite database.');
});

db.run(`CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT,
  date TEXT,
  time TEXT,
  location TEXT,
  description TEXT,
  organizer TEXT,
  category TEXT,
  image TEXT
)`);

app.get('/events', (req, res) => {
  db.all('SELECT * FROM events', [], (err, rows) => {
    if (err) {
      res.status(500).json({ error: err.message });
    } else {
      res.json(rows);
    }
  });
});

app.post('/events', (req, res) => {
  const { title, date, time, location, description, organizer, category, image } = req.body;
  db.run(
    `INSERT INTO events (title, date, time, location, description, organizer, category, image) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [title, date, time, location, description, organizer, category, image],
    function (err) {
      if (err) {
        res.status(500).json({ error: err.message });
      } else {
        res.json({ id: this.lastID });
      }
    }
  );
});

app.listen(3000, () => {
  console.log('Backend running on http://localhost:3000');
});

